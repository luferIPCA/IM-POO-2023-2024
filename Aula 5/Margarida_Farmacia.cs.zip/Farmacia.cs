﻿// Farmacia.cs
//
//
// margaridarodrigues
// a26418@alunos.ipca.pt
// 10/10/2023

namespace Aula10._10
{
    public class Farmacia
	{
        #region Atributes

        const int MAX = 500;
        private string nome;
        private Medicamento[] medicamentos;
        //nunca criar uma propriedade para o array pela privacidade dos dados
        //só preciso de propriedades para manipular atributos no exterior
        private int totMedicamentos; //indica quantos medicamentos tenho na farmacia 

        #endregion

        #region Constructor
        /// <summary>
        /// The default Constructor.
        /// </summary>
        public Farmacia()
        {
            totMedicamentos = 0;
            nome = "Nova";
            //Alocar memória para o array
            medicamentos = new Medicamento[MAX];
            //Inicializar
            for (int i = 0; i < MAX; i++)
            {
                medicamentos[i] = new Medicamento();
            }
        }

        public Farmacia(string nome)
        {
            this.nome = nome;
            totMedicamentos = 0;
            //Alocar memória para o array
            medicamentos = new Medicamento[MAX];
            //Inicializar
            for (int i = 0; i < MAX; i++)
            {
                medicamentos[i] = new Medicamento();
            }
        }

        public Farmacia(string nome, int tot)
        {
            this.nome = nome;
            totMedicamentos = 0;
            //Alocar memória para o array
            medicamentos = new Medicamento[tot];
            //Inicializar
            for (int i = 0; i < MAX; i++)
            {
                medicamentos[i] = new Medicamento();
            }
        }
        #endregion

        #region Propriedades
        public string Nome
        {
            get
            {
                return nome;
            }
            set
            {
                nome = value;
            }
        }


        #endregion

        #region OutrosMetodos
        public bool InsereMedicamentoFarmacia(Medicamento m1)
        {
            if (ExisteMedicamentoFarmacia(m1)) return false;
            medicamentos[totMedicamentos] = m1;
            totMedicamentos++;
            return true;
        }

        public bool ExisteMedicamentoFarmacia(Medicamento m1)
        {
            foreach (Medicamento m in medicamentos)
            {
                //if (m.Nome == m1.Nome) return true;
                if (m == m1) return true;
                //if (m1.Nome.Equals(m.Nome)) return true;
                //if (String.Compare(m1.Nome, m.Nome)==0) return true;
            }
            return false;
        }
        /// <summary>
        /// Outro metodo que passa apenas como parametro o nome e o tipo - poupa memoria!!
        /// </summary>
        /// <param name="nome"></param>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public bool ExisteMedicamentoFarmacia(string nome, TipoMedi tipo)
        {
            foreach (Medicamento m in medicamentos)
            {
                if (m.Nome.Equals(nome) && m.Tipo == tipo) return true;
            }
            return false;
        }
        /// <summary>
        /// Metodo que devolve quantos medicamentos existem de um tipo
        /// </summary>
        /// <returns></returns>
        public int QuantosMedicamentosExistem(TipoMedi tipo)
        {
            int contador = 0;
            foreach(Medicamento m in medicamentos)
            {
                if (m.Tipo.Equals(tipo))
                    contador++;
            }
            return contador;
        }
        /// <summary>
        /// Metodo que devolve quantos medicamentos existem de um tipo e com determinado nome
        /// </summary>
        /// <param name="nome"></param>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public int QuantosMedicamentosExistem(string nome, TipoMedi tipo)
        {
            int contador = 0;
            foreach (Medicamento m in medicamentos)
            {
                if (m.Tipo.Equals(tipo) && string.Compare(m.Nome,nome)==0)
                    contador++;
            }
            return contador;
        }
        /// <summary>
        /// Metodo que devolve a posicao do array onde esta determinado medicamento com nome e tipo
        /// </summary>
        /// <param name="nome"></param>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public int OndeExisteMedicamentos(string nome, TipoMedi tipo)
        {
            for(int i=0; i< totMedicamentos; i++)
            {
                if (medicamentos[i].Tipo.Equals(tipo) && string.Compare(medicamentos[i].Nome, nome) == 0)
                    return i;
            }
      return -1;
        }
        #endregion
    }
}